# CLAUDE CODE — YT AUTO COMMAND CENTER
## Full Build Brief — Send this file + 2 reference files to Claude Code

---

## FILES TO SUBMIT TO CLAUDE CODE

Send these 3 files together:
1. `CLAUDE_CODE_BUILD_BRIEF.md` — this file (the build instructions)
2. `YT_AUTO_COMMAND_CENTER.md` — all channel data, pipeline, repos, tools
3. `YT_COMPLIANCE_SHIELD.md` — compliance rules, scorecard, threat categories

---

## THE BUILD

Build a full web app called **LemonberryX** — a personal YouTube channel operations dashboard for managing 4 channels, automating content production, tracking pipeline stages, running compliance checks, and triggering n8n automations. Deploy to Vercel. This is a personal tool — single user.

---

## STACK

```
Framework:     Next.js 15 (App Router) + TypeScript
Styling:       Tailwind CSS
Database:      Supabase (JS SDK — direct client-side calls with RLS)
Auth:          Supabase Auth (email/password — single user)
AI:            Anthropic Claude API (server-side via Next.js API routes)
Automation:    n8n webhooks on Oracle Cloud (POST requests from frontend)
Deployment:    Vercel (same GitHub → Vercel pipeline as other projects)
Package mgr:   pnpm
```

---

## DESIGN SYSTEM — GLASSMORPHISM + GRADIENT MESH

This is the most important section. Every component follows this exactly.

### Base Colors
```css
--bg-base:     #0F0A1E    /* page background */
--bg-surface:  #13102A    /* elevated surface */
--bg-card:     rgba(255,255,255,0.06)  /* card background */
--bg-card-hover: rgba(255,255,255,0.09)

--text-primary:   #FFFFFF
--text-secondary: rgba(255,255,255,0.60)
--text-muted:     rgba(255,255,255,0.35)

--border:      rgba(255,255,255,0.10)
--border-hover: rgba(255,255,255,0.20)
```

### Gradient Blob System
Background has 5 animated floating blobs — blurred, organic, layered. Do not make them move fast — slow drift, subtle.
```css
--blob-purple:  #7C3AED   /* top-left */
--blob-pink:    #D946EF   /* top-right */
--blob-cyan:    #06B6D4   /* bottom-right */
--blob-amber:   #F59E0B   /* bottom-left */
--blob-green:   #10B981   /* center-right, smaller */

/* blob implementation */
.blob {
  position: fixed;
  border-radius: 50%;
  filter: blur(80px);
  opacity: 0.25;
  animation: drift 20s ease-in-out infinite alternate;
}
```

### Glassmorphism Cards
```css
.glass-card {
  background: rgba(255, 255, 255, 0.06);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.10);
  border-radius: 16px;
}
.glass-card:hover {
  background: rgba(255, 255, 255, 0.09);
  border-color: rgba(255, 255, 255, 0.20);
}
```

### Accent Gradient
Used on active states, buttons, badges, and highlights:
```css
--gradient-primary: linear-gradient(135deg, #7C3AED 0%, #D946EF 50%, #06B6D4 100%);
--gradient-gold:    linear-gradient(135deg, #F59E0B 0%, #EF9F27 100%);
```

### Typography

**Two custom fonts — both required:**

```
1. Dropline (DroplineRegular-Wpegz.otf)
   — Used for: all body text, nav items, labels, descriptions, small text
   — Place in: /public/fonts/DroplineRegular-Wpegz.otf
   — Load via @font-face in globals.css

2. Gradient Header Font (CSS effect — no separate file)
   — Used for: ALL headings, page titles, brand name "LemonberryX", section headers
   — Typeface base: Clash Display Bold or Outfit Bold (Google Fonts)
   — Effect: CSS gradient text (background-clip: text)
   — Gradient: linear-gradient(135deg, #F59E0B, #D946EF, #7C3AED, #06B6D4)
   — Applies the pastel gradient across large display text
```

```css
/* globals.css */
@font-face {
  font-family: 'Dropline';
  src: url('/fonts/DroplineRegular-Wpegz.otf') format('opentype');
  font-weight: normal;
  font-style: normal;
  font-display: swap;
}

@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@700;800;900&display=swap');

/* Body / all regular text */
body, p, span, label, input, button, td {
  font-family: 'Dropline', sans-serif;
}

/* All headings — gradient text effect */
h1, h2, h3, .brand-text, .page-title, .gradient-heading {
  font-family: 'Outfit', sans-serif;
  font-weight: 800;
  background: linear-gradient(135deg, #F59E0B 0%, #D946EF 35%, #7C3AED 65%, #06B6D4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* Brand name LemonberryX in sidebar */
.brand-name {
  font-family: 'Outfit', sans-serif;
  font-weight: 900;
  font-size: 22px;
  background: linear-gradient(135deg, #F59E0B, #D946EF, #7C3AED);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
```

### 3D Animations

Use Three.js (r128 via CDN or npm) OR pure CSS 3D transforms for performance. Implement these:

**1. Floating 3D Lemon + Berry logo element (sidebar top)**
```tsx
// Small 3D rotating lemon emoji-style object next to brand name
// CSS 3D: rotate on Y axis slowly, bob up and down
.logo-3d {
  animation: float3d 6s ease-in-out infinite;
  transform-style: preserve-3d;
}
@keyframes float3d {
  0%, 100% { transform: translateY(0px) rotateY(0deg); }
  50% { transform: translateY(-8px) rotateY(180deg); }
}
```

**2. 3D Card tilt effect on Channel cards (dashboard)**
```tsx
// On mouse move over card — tilt follows cursor (parallax tilt)
// Library: use vanilla-tilt.js or implement with mouse event listeners
// Effect: card tilts max 8deg on X/Y, subtle shine overlay moves with tilt
// Install: npm install vanilla-tilt
import VanillaTilt from 'vanilla-tilt';
useEffect(() => {
  VanillaTilt.init(cardRef.current, {
    max: 8, speed: 400, glare: true, 'max-glare': 0.15
  });
}, []);
```

**3. 3D rotating gradient sphere (hero/dashboard background)**
```tsx
// Large semi-transparent 3D sphere in background, slow rotation
// Pure CSS — no Three.js needed
.sphere-3d {
  width: 400px; height: 400px;
  border-radius: 50%;
  background: radial-gradient(circle at 35% 35%, #D946EF, #7C3AED, #0F0A1E);
  box-shadow: inset -30px -30px 60px rgba(0,0,0,0.5),
              0 0 80px rgba(124,58,237,0.3);
  animation: rotateSphere 20s linear infinite;
  position: fixed; opacity: 0.15; pointer-events: none;
}
@keyframes rotateSphere {
  from { transform: rotate3d(1, 1, 0, 0deg); }
  to   { transform: rotate3d(1, 1, 0, 360deg); }
}
```

**4. Staggered 3D card entrance animation (page load)**
```tsx
// Cards animate in from below with 3D flip — staggered per card
// Use Framer Motion:
// npm install framer-motion
import { motion } from 'framer-motion';
const cardVariants = {
  hidden: { opacity: 0, y: 60, rotateX: -15 },
  visible: (i) => ({
    opacity: 1, y: 0, rotateX: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: 'easeOut' }
  })
};
// Wrap each ChannelCard with:
<motion.div variants={cardVariants} initial="hidden" animate="visible" custom={index}>
```

**5. Pipeline stage progress — 3D coin flip animation**
```tsx
// When a stage is marked complete → coin flip animation (Y-axis 360deg)
// Stage dot flips from pending grey to done green
.stage-dot.completing {
  animation: coinFlip 0.6s ease-in-out forwards;
}
@keyframes coinFlip {
  0%   { transform: rotateY(0deg); }
  50%  { transform: rotateY(90deg); background: grey; }
  100% { transform: rotateY(360deg); background: #10B981; }
}
```

**Packages to install:**
```bash
npm install framer-motion vanilla-tilt
npm install three @types/three  # only if using Three.js sphere
```

### Status Badges
```css
.badge-live:          background: rgba(16,185,129,0.15); color: #10B981; border: 1px solid rgba(16,185,129,0.3);
.badge-repositioning: background: rgba(245,158,11,0.15); color: #F59E0B; border: 1px solid rgba(245,158,11,0.3);
.badge-paused:        background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.5); border: 1px solid rgba(255,255,255,0.12);
```

### Warning Levels (Compliance)
```css
.warning-critical: border-left: 3px solid #EF4444; background: rgba(239,68,68,0.06);
.warning-high:     border-left: 3px solid #F59E0B; background: rgba(245,158,11,0.06);
.warning-medium:   border-left: 3px solid #06B6D4; background: rgba(6,182,212,0.06);
```

---

## SUPABASE SCHEMA

Create these tables:

```sql
-- Channels
create table channels (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  niche text,
  status text default 'paused', -- 'live' | 'repositioning' | 'paused'
  rpm_target text,
  rpm_pct integer default 0,
  audience text default 'US',
  cpm_tier text,
  note text,
  pipeline_stage integer default 0,
  created_at timestamptz default now()
);

-- Content Queue
create table queue (
  id uuid default gen_random_uuid() primary key,
  title text not null,
  channel_id uuid references channels(id),
  day_number integer,
  source text default 'Manual',
  status text default 'idea', -- 'idea' | 'research' | 'script' | 'production' | 'done'
  priority text default 'mid', -- 'high' | 'mid' | 'low'
  ab_curiosity text,
  ab_fear text,
  ab_result text,
  script_content text,
  compliance_score integer,
  notes text,
  created_at timestamptz default now()
);

-- Compliance Logs
create table compliance_logs (
  id uuid default gen_random_uuid() primary key,
  queue_id uuid references queue(id),
  channel_id uuid references channels(id),
  score integer,
  originality_score integer,
  production_score integer,
  compliance_score integer,
  flags jsonb,
  checked_at timestamptz default now()
);

-- Automation Logs
create table automation_logs (
  id uuid default gen_random_uuid() primary key,
  action text not null,
  channel_id uuid references channels(id),
  queue_id uuid references queue(id),
  status text default 'pending', -- 'pending' | 'running' | 'done' | 'error'
  payload jsonb,
  result jsonb,
  triggered_at timestamptz default now()
);
```

Seed channels with this data:
```sql
insert into channels (name, niche, status, rpm_target, rpm_pct, audience, cpm_tier, note, pipeline_stage) values
('Grimm Archives', 'Money heists · Hidden wealth · Lost treasure', 'live', '$18–45', 60, 'US', 'Finance', 'Active — 30-day content plan loaded', 0),
('Channel 2', 'Betrayal & Revenge True Stories', 'repositioning', '$12–13', 15, 'US', 'Drama', '21x growth niche — fastest path to YPP', 0),
('Channel 3', 'Jungian Psychology & Shadow Work', 'paused', '$7–12', 8, 'Global', 'Education', 'Slow burn — high LTV for digital products', 0),
('Channel 4', 'Sleep Soundscapes & Sleep Stories', 'paused', '$10.92', 8, 'Global', 'Wellness', 'Passive — 2 uploads/month', 0);
```

Seed the first 10 queue items for Grimm Archives after channels are created.

---

## APP STRUCTURE

```
app/
├── layout.tsx              # root layout — blobs, fonts, Supabase provider
├── page.tsx                # redirect to /dashboard
├── dashboard/page.tsx      # channels overview
├── queue/page.tsx          # content queue
├── pipeline/page.tsx       # production pipeline tracker
├── script/page.tsx         # script engine (Claude API)
├── compliance/page.tsx     # compliance checker
├── tools/page.tsx          # automation triggers
├── api/
│   ├── script/route.ts     # POST — calls Claude API, returns script
│   ├── comply/route.ts     # POST — calls Claude API, returns compliance score
│   └── trigger/route.ts    # POST — calls n8n webhook
components/
├── layout/
│   ├── Sidebar.tsx         # left nav — gradient active state
│   ├── TopBar.tsx          # page title + save indicator
│   └── GradientBlobs.tsx   # fixed background blobs
├── dashboard/
│   ├── ChannelCard.tsx     # glass card per channel
│   └── ChannelGrid.tsx
├── queue/
│   ├── QueueItem.tsx       # single video row
│   ├── QueueFilters.tsx    # channel filter + search
│   └── AddVideoModal.tsx   # modal for adding new items
├── pipeline/
│   ├── PipelineStage.tsx   # single stage row
│   └── PipelineTracker.tsx
├── script/
│   ├── ScriptForm.tsx      # topic + key points inputs
│   ├── ABTestPanel.tsx     # 3 variant inputs
│   └── ScriptOutput.tsx    # generated script display
├── compliance/
│   ├── ComplianceScorecard.tsx
│   ├── ThreatCard.tsx      # per threat category
│   └── ScoreGate.tsx       # 7/10 pass/fail gate
└── tools/
    ├── ToolCard.tsx        # clickable tool link
    ├── WebhookButton.tsx   # n8n trigger button
    └── WeeklySchedule.tsx
lib/
├── supabase/
│   ├── client.ts           # browser client
│   └── types.ts            # generated types
├── claude.ts               # Claude API helper
└── n8n.ts                  # n8n webhook helper
```

---

## PAGES — DETAILED SPEC

### 1. Dashboard `/dashboard`

Left sidebar navigation with gradient active indicator. Main content: header with date + "4 channels · 30 videos queued". Grid of 4 ChannelCards.

**ChannelCard:**
- Glass card, hover effect
- Channel name (Syne font, 16px bold)
- Niche text (secondary color, 12px)
- Status badge (color-coded)
- 3 stats: RPM Target, Audience, CPM Tier
- RPM progress bar (gradient fill, animated)
- Editable note (click to edit inline → save to Supabase)
- Click badge cycles status: live → repositioning → paused → live
- Bottom: "Pipeline stage: X/11" mini indicator

---

### 2. Queue `/queue`

**Filters bar:** All | Grimm Archives | Channel 2 | Channel 3 | Channel 4
**Stats pills:** Script ready (green) | Researched (blue) | Ideas (gray)
**Search:** real-time filter by title

**Queue item row:**
- Priority dot (click to cycle high→mid→low) — colored
- Day label (D1, D2... or auto-numbered)
- Title (click to open detail side panel)
- Channel name chip
- Source chip (AI Ask Studio / NotebookLM / Manual)
- Status badge
- Hover: delete button (✕) appears right

**Add Video button:** opens modal with fields: title, channel, source, status, priority

**Detail side panel** (slides in from right when title clicked):
- Full title editable
- AB Test variants: Curiosity / Fear / Result (3 input fields)
- Status updater
- Script content textarea
- Compliance score display (if checked)
- "Generate Script" button → calls /api/script
- "Check Compliance" button → calls /api/comply
- Save button → Supabase update

---

### 3. Pipeline `/pipeline`

**Channel selector tabs:** Grimm Archives | Channel 2 | Channel 3 | Channel 4

**11 stages** (from YT_AUTO_COMMAND_CENTER.md):
```
0  — Compliance Brief Check      [Before scripting]
1  — Research (3+ sources)       [Crawl4AI + NotebookLM + AI Ask Studio]
2  — Script + Creator Take       [claude-youtube framework + SSML cues]
3  — Title Alignment Check       [Verify script matches metadata]
4  — AB Test 3 Variants          [Curiosity / Fear / Result]
5  — Visuals (60%+ motion)       [Whisk + Hunyuan clips]
6  — Voiceover (with direction)  [ElevenLabs stability <0.45]
7  — Auto-Edit + Assembly        [auto-editor + CapCut]
8  — Thumbnail (3 variants)      [Canva]
8.5— Compliance Scorecard        [Must score 7/10+]
9  — Upload                      [AI disclosure ON]
10 — Shorts Factory              [short-video-maker + AI-Shorts-Generator]
```

Each stage row:
- Status dot: done (green) / current (gradient glow) / pending (dim)
- Stage name + description
- Tool chip (right side)
- Click → marks as current stage, saves to Supabase
- Progress bar at top showing X/11 complete

Stats row: Progress %, ~90 mins/video, 3.5 hrs/week, stages left

---

### 4. Script Engine `/script`

**Left: Script Form**
- "Video topic / title" input (pre-fills if navigated from queue item)
- "Key points to cover" textarea
- "Generate Full Retention Script" button → POST /api/script → streams response
- Loading state: animated gradient border on the button

**AB Test Panel** (below form):
- 3 columns: Curiosity (blue badge) / Fear (red badge) / Result (green badge)
- Each with: type badge, text input, hint text
- "Generate AB Variants" button → calls /api/script with AB prompt

**Pre-upload Checklist** (below AB panel):
- 9 checkbox items from YT_COMPLIANCE_SHIELD.md
- Click to check/uncheck → saves to localStorage
- "Reset for next video" button
- Done count shown: "5/9 checked"

**Right: Retention Benchmarks sidebar**
- Metric cards: 70%+ AVD, 80%+ retention at 30s, 8 min mid-roll, etc.
- Color coded: green (target) / amber (ok) / red (danger)
- Rule cards: "Open loops = +68% completion", etc.

**Script Output** (appears below after generation):
- Full script with syntax highlighting
- Cue markers [VISUAL] [SFX] [CAMERA CHANGE] highlighted in amber
- Copy button
- Save to queue button → writes to Supabase queue item

---

### 5. Compliance `/compliance`

**Compliance Scorecard at top:**
```
Score: 0/10 (updates live as checkboxes filled)
[ ] Originality (3 pts)     — 3 sub-checks
[ ] Production Auth (4 pts) — 4 sub-checks
[ ] Policy (3 pts)          — 3 sub-checks
PASS bar (green at 7+) / FAIL bar (red below 7)
```

**10 Threat Cards** (from YT_COMPLIANCE_SHIELD.md):
Each card:
- Warning level badge: 🔴 CRITICAL / 🟠 HIGH / 🟡 MEDIUM
- Threat name + short description
- "Detected Issue" expandable section
- "Solution" expandable section
- "Tools/Instruction" expandable section
- Accordion open/close behavior

**AI Compliance Checker:**
- Textarea: paste script here
- "Run Compliance Check" button → POST /api/comply → Claude analyzes
- Returns: score out of 10, per-category breakdown, specific flags
- Results displayed as colored score breakdown

**Strike Response Protocol:**
- Collapsible section at bottom
- 8-step emergency protocol (from YT_COMPLIANCE_SHIELD.md)
- Red border card, urgent styling

---

### 6. Tools `/tools`

**Production Stack grid (2 columns):**
14 tool cards. Each:
- Dark glass card with colored icon dot
- Tool name + use description
- External link opens in new tab
- Hover: gradient border glow

Tools: Google Whisk, Hunyuan Video, NotebookLM, AI Ask Studio, ElevenLabs, CapCut, Canva, YouTube Studio, auto-editor, short-video-maker, AI-Shorts-Generator, ViMax, Crawl4AI, OpenMontage

**n8n Automation Triggers:**
Glass panel with title "Automation Triggers"
4 buttons (each POST to n8n webhook):
- "🔍 Run Daily Research" — triggers Crawl4AI scrape
- "🎬 Generate Short" — triggers short-video-maker Docker
- "✂️ Detect Viral Clips" — triggers AI-Shorts-Generator
- "🤖 Full ViMax Run" — triggers ViMax pipeline

Each button:
- Click → shows loading spinner
- On success → green toast "Triggered successfully"
- On error → red toast with error message
- Logs trigger to `automation_logs` table in Supabase

**Weekly Schedule table:**
Glass card, 5 rows (Mon/Tue/Wed/Thu/Sat), task, time column

**Repo Quick Links:**
Icon grid of all cloned repos — click opens GitHub URL

---

## API ROUTES

### POST /api/script
```typescript
// Body: { topic: string, keyPoints: string, type: 'script' | 'ab' }
// Returns: { script: string } or { variants: {curiosity, fear, result} }

// Claude prompt for full script:
const systemPrompt = `You are a YouTube script writer for Grimm Archives — a US-audience history/finance mystery channel targeting $18-45 RPM.

Apply the AgriciDaniel/claude-youtube retention framework:
- Hook: Grab (0-5s) + Promise (5-15s) + Stakes (15-30s) — target 70%+ retention at 30s
- NEVER open with "Hey guys welcome back"
- Pattern interrupt every 60-90s: [CAMERA CHANGE] [B-ROLL CUE] [GRAPHIC] [SOUND EFFECT] [UNEXPECTED STAT]
- Soft CTA at ~1 min
- Open loop mid-video
- Re-hook at 60% mark
- Hard CTA in outro — maintain energy to last second
- Include [VISUAL: description] and [SFX: description] cue markers
- End with Pattern Interrupt Log and Retention Risk Map
- Add a "Grimm Archives Take" — original theory or financial analysis not in any source

Script must match title/description exactly (YouTube AI reads captions).
Format for easy CapCut assembly.`
```

### POST /api/comply
```typescript
// Body: { script: string, title?: string }
// Returns: { score: number, originality: number, production: number, policy: number, flags: string[], recommendations: string[] }

// Claude analyzes against YT_COMPLIANCE_SHIELD.md rules
// Returns structured JSON score breakdown
```

### POST /api/trigger
```typescript
// Body: { action: string, payload?: object }
// Calls n8n webhook: process.env.N8N_WEBHOOK_BASE_URL + '/' + action
// Logs to automation_logs table
// Returns: { success: boolean, message: string }
```

---

## ENV VARS NEEDED

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
ANTHROPIC_API_KEY=
N8N_WEBHOOK_BASE_URL=http://YOUR_ORACLE_IP:5678/webhook
PEXELS_API_KEY=
NEXT_PUBLIC_APP_NAME=LemonberryX
```

---

## SIDEBAR NAVIGATION

```
LemonberryX        ← logo + brand name (Syne font)
━━━━━━━━━━━━━━━━━━━━━━
📺  Dashboard
📋  Queue         [30] badge
⚙️  Pipeline
✍️  Script Engine
🛡️  Compliance
🔧  Tools
━━━━━━━━━━━━━━━━━━━━━━
[gradient blob decoration at bottom]
```

Active nav item: gradient background (purple→pink), white text, subtle glow.

---

## GRADIENT BLOB COMPONENT

```tsx
// components/layout/GradientBlobs.tsx
// Fixed position, behind everything (z-0)
// 5 blobs with different sizes, positions, colors, animation delays
// Tailwind: fixed inset-0 pointer-events-none overflow-hidden -z-10

const blobs = [
  { color: '#7C3AED', size: 600, top: '-10%', left: '-5%', delay: '0s' },
  { color: '#D946EF', size: 500, top: '-5%', right: '-10%', delay: '5s' },
  { color: '#06B6D4', size: 450, bottom: '-10%', right: '-5%', delay: '10s' },
  { color: '#F59E0B', size: 400, bottom: '-5%', left: '-10%', delay: '3s' },
  { color: '#10B981', size: 300, top: '40%', right: '20%', delay: '7s' },
]
// Each: border-radius: 50%, filter: blur(80px), opacity: 0.20, animation: drift 20s ease-in-out infinite alternate
```

---

## DEPLOYMENT

```bash
# GitHub repo name
lemonberryx

# Vercel settings
Framework: Next.js
Root directory: ./
Build command: pnpm build
Output directory: .next
Node version: 20.x

# After deploy, add env vars in Vercel dashboard
# Same process as LemonX AI Studio
```

---

## GRIMM ARCHIVES QUEUE — SEED DATA

Seed these 30 items linked to Grimm Archives channel after Supabase is set up:

```
D1  The $500 Million Ghost Gallery: The World's Most Expensive Unsolved Heist
D2  The Lufthansa Heist: The Truth Behind America's Greatest Cash Robbery
D3  The Lost Dutchman's Gold Mine: A $200 Million Cursed Fortune
D4  The $600,000,000 Phantom: How the Ronin Network Was Emptied
D5  Yamashita's Gold: The Hunt for WWII's Most Controversial Fortune
D6  The Copper Scroll: A 2,000-Year-Old Map to Millions
D7  The Original $20 Billion Scam: The Rise and Fall of Charles Ponzi
D8  The Nazi Gold Train: A $3 Billion Ghost Story
D9  The Mt. Gox Meltdown: The Mystery of the 850,000 Missing Bitcoin
D10 D.B. Cooper: The Only Unsolved Skyjacking in History
D11 The $300 Million Ghost Room: Where is the Amber Room?
D12 El Dorado: The Deadly Truth Behind the City of Gold
D13 The $20 Million Liquid Gold Heist: The Great Maple Syrup Robbery
D14 King John's Lost Fortune: A 1,000-Year-Old $70 Million Cold Case
D15 Dead Men Tell No Tales: The $200,000,000 Locked Crypto Vault
D16 Finding $10 Million in a Backyard: The Mystery of the Saddle Ridge Hoard
D17 The Oak Island Money Pit: The World's Most Expensive Unsolved Hole
D18 The $400 Billion King: How Mansa Musa Destroyed an Economy with Gold
D19 The Vanishing Fortune: Where Did the Romanov Gold Go?
D20 George Washington: The Secret Real Estate Empire of the First President
D21 The $100 Billion Ghost: The Secret Wealth of Howard Hughes
D22 The Trillion-Dollar Theft: The Secret Files of Nikola Tesla
D23 The Man Who Never Died: The Financial Secrets of the Count of Saint Germain
D24 The Golden Library: Ivan the Terrible's $1 Billion Missing Archive
D25 Charlemagne's Secret: The $50 Million Artifact of Power
D26 The $33 Million Mistake: The Hunt for the Missing Fabergé Eggs
D27 The Vatican's Secret Vault: $15 Billion in Hidden History?
D28 The Vanishing $160 Million: Where is the Confederate Gold?
D29 The Forbidden Tomb: A $20 Billion Fortune We're Too Scared to Open
D30 D.B. Cooper Follow-up: New Evidence from the Washington Wilderness

Priority: D1-D10 = high, D11-D20 = mid, D21-D30 = low
Source: AI Ask Studio
Status: script
```

---

## WHAT NOT TO BUILD

- No payment/billing system
- No multi-user / team features
- No video upload or storage (videos stay on local machine)
- No YouTube API integration yet (manual upload via YouTube Studio)
- No real-time collaboration
- Keep it lean — personal tool, not SaaS

---

## FINAL CHECKLIST BEFORE SHIPPING

- [ ] All 6 pages render without errors
- [ ] Supabase CRUD works: channels, queue, compliance logs, automation logs
- [ ] Script generation calls Claude API and streams response
- [ ] Compliance checker returns score breakdown
- [ ] n8n webhook buttons POST correctly and log to Supabase
- [ ] Gradient blobs render in background (not blocking interaction)
- [ ] Glass cards have correct backdrop-filter on all browsers
- [ ] All external tool links open in new tab
- [ ] Mobile responsive (at least readable on phone)
- [ ] Deployed to Vercel with all env vars set
- [ ] GitHub repo: nauxai-com/lemonberryx

